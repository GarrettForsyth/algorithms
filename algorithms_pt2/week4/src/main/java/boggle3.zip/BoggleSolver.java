import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdOut;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.Random;

public class BoggleSolver
{

    private BranchingTST<Integer> dictionaryTST;

    // Initializes the data structure using the given array of strings as the dictionary.
    // (You can assume each word in the dictionary contains only the uppercase letters A through Z.)
    public BoggleSolver(String[] dictionary){
        dictionaryTST = new BranchingTST<Integer>();
        createDictionaryFromArray(dictionary);

    }

    // Returns the set of all valid words in the given Boggle board, as an Iterable.
    public Iterable<String> getAllValidWords(BoggleBoard board){
        return BoggleDFS.search( board, dictionaryTST);
    }

    // Returns the score of the given word if it is in the dictionary, zero otherwise.
    // (You can assume the word contains only the uppercase letters A through Z.)
    public int scoreOf(String word){
        Integer score = dictionaryTST.get(word);
        return score == null ? 0 : score;
    }

    private void createDictionaryFromArray(String[] dictionary){
        for ( String word : dictionary ){
            int l = word.length();
            if      ( l < 3 ) dictionaryTST.put(word, 0);
            else if ( l < 5 ) dictionaryTST.put(word, 1);
            else if ( l < 6 ) dictionaryTST.put(word, 2);
            else if ( l < 7 ) dictionaryTST.put(word, 3);
            else if ( l < 8 ) dictionaryTST.put(word, 5);
            else              dictionaryTST.put(word, 11);
        }
    }

    public static void main(String[] args) {
        In in = new In("boggle/dictionary-yawl.txt");
        String[] dictionary = in.readAllStrings();
        BoggleSolver solver = new BoggleSolver(dictionary);
        BoggleBoard board = new BoggleBoard("boggle/board-points26539.txt");
        System.out.println(solver.getAllValidWords(board).toString());
        System.out.println(solver.getAllValidWords(board).toString());

        int score = 0;
        for (String word : solver.getAllValidWords(board)) {
            StdOut.println(word);
            score += solver.scoreOf(word);
        }
        StdOut.println("Score = " + score);

        int numBoards = 10;

        long start = System.currentTimeMillis();

        for (int i = 0; i < numBoards; i++){
            BoggleBoard b = new BoggleBoard(4,4);
            solver.getAllValidWords(b);
        }
        long end = System.currentTimeMillis();
        System.out.println("Solved " + (numBoards*1000)/(end-start) + " boards per second." );


        BoggleBoard board4x4 = new BoggleBoard("boggle/board4x4.txt");
        BoggleSolver solver4x4 = new BoggleSolver(dictionary);
        BoggleBoard boardMany = new BoggleBoard("boggle/board-points26539.txt");
        Random randGen = new Random();
        for (int i = 0; i < numBoards; i++){
            int randNum = randGen.nextInt(101)  ;

            System.out.println(randNum);
            if( randNum < 50){
                System.out.println(solver.getAllValidWords(board4x4));
            }
            else{
                System.out.println(solver.getAllValidWords(boardMany));
            }
        }

        System.out.println("Solved " + (numBoards*1000)/(end-start) + " boards per second." );
    }

}
