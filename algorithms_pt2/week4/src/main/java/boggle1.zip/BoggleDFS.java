import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Stack;

/**
 * The idea:
 *  For each boggle block
 *    Compute a DFS between each pair of blocks (note: not symmetric)
 *    Track all paths
 */
public class BoggleDFS{

    private final int numRows;
    private final int numCols;
    private final int total;

    private final BoggleBoard board;
    private final BranchingTST<Integer> dictionary;
    private HashSet<String> foundWords;
    public ArrayList<String> foundSequences;

    private boolean[] onPath;
    private StringBuilder[] currentPathTo;

    private Stack<Integer> path;
    private StringBuilder currentSequence;

    // optimizations
    private LinkedList<Integer>[] neighbours; // cache local neighbours
    private Stack<Integer> changes; // track which index change each iteration

    public BoggleDFS(BoggleBoard board, BranchingTST<Integer> dictionary) {
        numCols = board.cols();
        numRows = board.rows();
        total = numCols*numRows;

        this.board = board;
        this.dictionary = dictionary;
        foundWords = new HashSet<String>();
        currentPathTo = new StringBuilder[total];
        foundSequences = new ArrayList<String>();


        neighbours = new LinkedList[total];
        changes = new Stack<Integer>();


        onPath = new boolean[numRows*numCols];

        for (int i = 0; i < total; i++ ){
            currentPathTo[i] = new StringBuilder();
        }


        for (int c = 0; c < numCols; c++) {
            for (int r = 0; r < numRows; r++) {
                dfsAllPaths(getNodeId(r, c));
            }
        }
        /*
        path = new Stack<Integer>();
        currentSequence = new StringBuilder();
        dfs(getNodeId(0,0), getNodeId(0, 1));
        path = new Stack<Integer>();
        currentSequence = new StringBuilder();
        dfs(getNodeId(0,0), getNodeId(0, 2));
        System.out.println(foundSequences.contains("ATE"));
        System.out.println(foundSequences.contains("APE"));

        System.out.println(foundWords.contains("ATE"));
        System.out.println(foundWords.contains("APE"));
        */


    }

    public Iterable<String> getFoundSequences(){
        return foundWords;
    }

    private void unwind(){
        while (!changes.isEmpty()){
            int x = changes.pop();
            onPath[x] = false;
            currentPathTo[x] = new StringBuilder();
        }
    }

    /* Compute dfs between one node and all other nodes */
    private void dfsAllPaths(int startNode) {
        for ( int c = 0; c < numCols; c++) {
            for (int r = 0; r < numRows; r++) {
                unwind();
                path = new Stack<Integer>();
                currentSequence = new StringBuilder();
                currentPathTo[startNode].append(getLetter(startNode));
                dfs(startNode, getNodeId(r, c));
            }
        }
    }

    /* DFS from start to target */
    private void dfs(int v, int t){
        path.push(v);
        onPath[v] = true;

        // prune branch if no words contain the sequence as a prefix
        currentSequence.append(getLetter(v));
        if (getLetter(v) == 'Q') currentSequence.append('U');
        if (currentSequence.length() >= 2 && !dictionary.containsPrefix(currentSequence.toString())){
            path.pop();
            if (currentSequence.charAt(currentSequence.length()-2) == 'Q'){
                currentSequence.deleteCharAt(currentSequence.length()-1);
            }
            currentSequence.deleteCharAt(currentSequence.length()-1);
            onPath[v] = false;
            return;
        }
        // only search for words longer than length 2 since all others score 0
        if (currentSequence.length() > 2 && dictionary.contains(currentSequence.toString()) && !foundWords.contains(currentSequence.toString())){
            foundWords.add(currentSequence.toString());
        }

        //if ( v == t) processCurrentPath();

        LinkedList<Integer> currentNeighbours = neighbours[v] == null ? getNeighbours(v) : neighbours[v];

        for(int w : currentNeighbours){
          if (!onPath[w]){
                  dfs(w, t);
            }
        }

        path.pop();
        if (currentSequence.length() > 1 && currentSequence.charAt(currentSequence.length()-2) == 'Q'){
            currentSequence.deleteCharAt(currentSequence.length()-1);
        }
        currentSequence.deleteCharAt(currentSequence.length()-1);
        onPath[v] = false;
    }

    private void processCurrentPath(){
        Stack<Integer> reverse = new Stack<Integer>();
        StringBuilder sb = new StringBuilder();
        for (int v: path ) {
            sb.append(getLetter(reverse.push(v)));
        }
        foundSequences.add(sb.toString());
        System.out.println(sb.toString());
    }

    /* Gets all adjacent nodes to node */
    // TODO maybe cache neighbour lists
    private LinkedList<Integer> getNeighbours( int node){
        LinkedList<Integer> neighbours = new LinkedList<Integer>();
        if (!onTopEdge(node))              neighbours.add(node-numCols); //above
        if (!onBottomEdge(node))           neighbours.add(node+numCols); //below
        if (!onLeftEdge(node))             neighbours.add(node-1); //left
        if (!onRightEdge(node))            neighbours.add(node+1); //right
        if (hasTopLeftNeighbour(node))     neighbours.add(node-numCols-1);
        if (hasTopRightNeighbour(node))    neighbours.add(node-numCols+1);
        if (hasBottomLeftNeighbour(node))  neighbours.add(node+numCols-1);
        if (hasBottomRightNeighbour(node)) neighbours.add(node+numCols+1);
        return neighbours;
    }

    private boolean onTopEdge(int nodeId) {
        return (nodeId < numCols);
    }

    private boolean onBottomEdge(int nodeId) {
        return (nodeId >= ((numCols*numRows) - numCols));
    }

    private boolean onRightEdge(int nodeId) {
        return ((nodeId+numCols+1)%numCols == 0);
    }

    private boolean onLeftEdge(int nodeId) {
        return nodeId%numCols == 0;
    }

    private boolean hasTopLeftNeighbour(int nodeId) {
        return !(onTopEdge(nodeId) || onLeftEdge(nodeId));

    }

    private boolean hasTopRightNeighbour(int nodeId) {
        return !(onTopEdge(nodeId) || onRightEdge(nodeId));
    }

    private boolean hasBottomLeftNeighbour(int nodeId) {
        return  !(onBottomEdge(nodeId) || onLeftEdge(nodeId));
    }

    private boolean hasBottomRightNeighbour(int nodeId) {
        return !(onBottomEdge(nodeId) || onRightEdge(nodeId));
    }

    private int getNodeId(int row, int col) {
        return (row * numCols + col);
    }

    // returns coordinates (row, col)
    private int[] getNode2DCoord(int nodeId){
        int[] coords = new int[2];
        coords[1] = nodeId%numCols;
        coords[0] = nodeId/numCols;
        return coords;
    }

    private char getLetter(int nodeId){
        int[] coords = getNode2DCoord(nodeId);
        return board.getLetter(coords[0], coords[1]);
    }

    private boolean isOnBoard(int col, int row, BoggleBoard board) {
        return ((col >= 0 && col < board.cols()) && (row >= 0 && row < board.rows()));
    }

    private boolean isOnBoard(int nodeID){
        return ( nodeID >= 0 && nodeID < (numCols*numRows));
    }


    public static void main(String[] args) {
        BoggleBoard b = new BoggleBoard("boggle/board4x4.txt");

    }

}


